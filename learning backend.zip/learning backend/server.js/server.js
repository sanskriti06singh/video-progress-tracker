const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

// Simulated database for lectures
const lectures = [
  { id: 1, title: "Introduction to Biology", src: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm", duration: 600 },
  { id: 2, title: "Cell Structure and Function", src: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/bee.webm", duration: 900 },
  { id: 3, title: "Genetics Basics", src: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/river.webm", duration: 1200 }
];

// Simulated user progress data
// Format: { userId: { lectureId: progress_in_seconds, ... }, ... }
const userProgress = {};

// GET /lectures
app.get('/lectures', (req, res) => {
  res.json(lectures);
});

// GET /progress/:userId
app.get('/progress/:userId', (req, res) => {
  const userId = req.params.userId;
  const progress = userProgress[userId] || {};
  res.json(progress);
});

// POST /progress/:userId/:lectureId
app.post('/progress/:userId/:lectureId', (req, res) => {
  const userId = req.params.userId;
  const lectureId = req.params.lectureId;
  const { progress } = req.body;

  if (typeof progress !== 'number' || progress < 0) {
    return res.status(400).json({ error: 'Invalid progress value' });
  }

  if (!userProgress[userId]) {
    userProgress[userId] = {};
  }

  // Save max progress (don't allow lowering progress)
  const currentProgress = userProgress[userId][lectureId] || 0;
  if (progress > currentProgress) {
    userProgress[userId][lectureId] = progress;
  }

  res.json({ success: true });
});

app.listen(port, () => {
  console.log(`Backend API running on http://localhost:${port}`);
});
npm install express cors
